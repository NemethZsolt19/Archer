namespace Archer.Models
{
  public class Booking
  {
    public int Id { get; set; }
    public DateTime RentDay { get; set; }
    public int MachineId { get; set; }
  }
}
